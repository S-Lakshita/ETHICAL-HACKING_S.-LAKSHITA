from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename
from werkzeug.exceptions import RequestEntityTooLarge
import xml.etree.ElementTree as ET
import ipaddress, json, csv, os, uuid, subprocess, shutil, io
from datetime import datetime, timezone

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(APP_DIR, "data")
LATEST_SCAN = os.path.join(DATA_DIR, "latest_scan.json")
INCIDENTS_CSV = os.path.join(DATA_DIR, "incident_history.csv")
ALLOWED_EXTENSION = ".xml"
MAX_UPLOAD_BYTES = 10 * 1024 * 1024
MAX_SCAN_HOSTS = 256

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "local-development-key-change-me")
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_BYTES
os.makedirs(DATA_DIR, exist_ok=True)

INCIDENT_FIELDS = ["incident_id", "timestamp", "scanner_ip", "target_ip",
                   "detected_activity", "open_services", "risk_level", "incident_status"]

def ensure_local_files():
    if not os.path.exists(LATEST_SCAN):
        with open(LATEST_SCAN, "w", encoding="utf-8") as f:
            json.dump({"has_scan": False}, f, indent=2)
    if not os.path.exists(INCIDENTS_CSV):
        with open(INCIDENTS_CSV, "w", newline="", encoding="utf-8") as f:
            csv.DictWriter(f, fieldnames=INCIDENT_FIELDS).writeheader()

def read_latest_scan():
    ensure_local_files()
    try:
        with open(LATEST_SCAN, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {"has_scan": False}

def read_incidents():
    ensure_local_files()
    with open(INCIDENTS_CSV, "r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def classify_risk(open_count):
    if open_count <= 9: return "LOW"
    if open_count <= 19: return "MEDIUM"
    return "HIGH"

def parse_nmap_xml(file_stream, scanner_ip, source_label):
    try:
        root = ET.parse(file_stream).getroot()
    except ET.ParseError as exc:
        raise ValueError(f"Invalid Nmap XML: {exc}") from exc
    if root.tag != "nmaprun":
        raise ValueError("The file is not an Nmap XML scan document.")
    hosts = []
    for host in root.findall("host"):
        status_node = host.find("status")
        if status_node is not None and status_node.get("state") != "up":
            continue
        addresses = host.findall("address")
        target_ip = next((a.get("addr") for a in addresses
                          if a.get("addrtype") in ("ipv4", "ipv6")), "")
        if not target_ip:
            continue
        hostname_node = host.find("./hostnames/hostname")
        hostname = hostname_node.get("name", "") if hostname_node is not None else ""
        ports = []
        ports_node = host.find("ports")
        if ports_node is not None:
            for port in ports_node.findall("port"):
                state_node, service_node = port.find("state"), port.find("service")
                state = state_node.get("state", "unknown") if state_node is not None else "unknown"
                ports.append({
                    "port": int(port.get("portid", "0")),
                    "protocol": port.get("protocol", "unknown"),
                    "service": (service_node.get("name") if service_node is not None else None) or "unknown",
                    "product": service_node.get("product", "") if service_node is not None else "",
                    "version": service_node.get("version", "") if service_node is not None else "",
                    "state": state
                })
        open_ports = [p for p in ports if p["state"] == "open"]
        hosts.append({"ip": target_ip, "hostname": hostname, "all_ports": ports,
                      "open_ports": open_ports, "open_count": len(open_ports),
                      "risk_level": classify_risk(len(open_ports))})
    if not hosts:
        raise ValueError("No active hosts were found in the Nmap XML results.")
    all_ports = [p for h in hosts for p in h["all_ports"]]
    open_ports = [p for h in hosts for p in h["open_ports"]]
    review_ports = {
        135: "Windows RPC exposure should be limited to trusted networks.",
        139: "NetBIOS session service exposure should be reviewed.",
        445: "SMB/file-sharing exposure should be limited and hardened.",
        3389: "Remote Desktop exposure should be restricted.",
        23: "Telnet is unencrypted; replace with a secure alternative where possible."
    }
    flagged = []
    for h in hosts:
        for p in h["open_ports"]:
            if p["port"] in review_ports:
                flagged.append(f'{h["ip"]} — {p["port"]}/{p["protocol"]}: {review_ports[p["port"]]}')
    if not flagged:
        flagged = ["No ports matched the built-in exposure-review rules. This does not establish that hosts are secure."]
    recommendations = [
        "Verify that each open service is required for the device's role.",
        "Restrict access with host and network firewalls; allow only trusted source networks.",
        "Keep exposed services patched and disable unused services."
    ] if open_ports else ["No open ports were reported. Confirm scan scope and host availability."]
    if any(p["port"] == 445 for p in open_ports):
        recommendations.append("Review SMB sharing and enforce current SMB security settings.")
    if any(p["port"] == 135 for p in open_ports):
        recommendations.append("Limit RPC access to trusted internal systems.")
    if any(p["port"] == 5000 for p in open_ports):
        recommendations.append("Confirm that HTTP port 5000 is intended and not an exposed development server.")
    scan_start = root.get("startstr") or ""
    if not scan_start and root.get("start"):
        try:
            scan_start = datetime.fromtimestamp(int(root.get("start")), timezone.utc).astimezone().isoformat(timespec="seconds")
        except (ValueError, OSError):
            scan_start = "Not provided in XML"
    return {
        "has_scan": True, "uploaded_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "target_ip": source_label, "scanner_ip": scanner_ip,
        "scan_timestamp": scan_start or "Not provided in XML",
        "nmap_command": root.get("args", "Not recorded in XML"),
        "nmap_version": root.get("version", "Unknown"),
        "total_hosts": len(hosts), "hosts": hosts,
        "total_port_entries": len(all_ports), "open_count": len(open_ports),
        "open_ports": open_ports, "all_ports": all_ports,
        "open_services": sorted({p["service"] for p in open_ports}),
        "risk_level": classify_risk(len(open_ports)),
        "analysis_status": "Completed", "analysis_source": source_label,
        "observations": [f'{h["ip"]}: {p["port"]}/{p["protocol"]} ({p["service"]}) is open'
                         for h in hosts for p in h["open_ports"]],
        "suspicious_activity": flagged, "recommendations": recommendations,
        "analysis_summary": f"The scan found {len(hosts)} active host(s) and {len(open_ports)} open service(s). Open ports indicate network exposure; an Nmap service scan alone does not prove an intrusion."
    }

def save_scan(scan):
    with open(LATEST_SCAN, "w", encoding="utf-8") as f:
        json.dump(scan, f, indent=2)

def save_incident(scan):
    incident = {
        "incident_id": "INC-" + uuid.uuid4().hex[:10].upper(),
        "timestamp": datetime.now().astimezone().isoformat(timespec="seconds"),
        "scanner_ip": scan["scanner_ip"], "target_ip": scan["target_ip"],
        "detected_activity": f'Nmap scan; {scan.get("total_hosts", 1)} active host(s), {scan["open_count"]} open service(s)',
        "open_services": scan["open_count"], "risk_level": scan["risk_level"],
        "incident_status": "Under Review"
    }
    with open(INCIDENTS_CSV, "a", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=INCIDENT_FIELDS).writerow(incident)
    scan["incident"] = incident
    save_scan(scan)

def validate_scope(value):
    value = value.strip()
    try:
        if "/" in value:
            network = ipaddress.ip_network(value, strict=False)
            if network.version != 4 or not network.is_private:
                raise ValueError("Use an authorised private IPv4 network range only.")
            if network.num_addresses > MAX_SCAN_HOSTS:
                raise ValueError(f"For safety, the network range must contain no more than {MAX_SCAN_HOSTS} addresses.")
            return str(network)
        address = ipaddress.ip_address(value)
        if address.version != 4 or not address.is_private:
            raise ValueError("Use an authorised private IPv4 address only.")
        return str(address)
    except ValueError as exc:
        if "For safety" in str(exc) or "Use an authorised" in str(exc):
            raise
        raise ValueError("Enter a valid private IPv4 address or network range, such as 10.0.2.2 or 10.0.2.0/24.") from exc

def run_nmap_scan(scope):
    nmap_path = shutil.which("nmap")
    if not nmap_path:
        raise ValueError("Nmap was not found. Install Nmap on this Windows computer and make sure 'nmap' is available in PATH.")
    command = [nmap_path, "-sV", "-oX", "-", scope]
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=600, check=False)
    except subprocess.TimeoutExpired as exc:
        raise ValueError("The scan timed out. Try a smaller authorised target range.") from exc
    if result.returncode not in (0, 1) or not result.stdout.strip():
        message = (result.stderr or result.stdout or "Nmap did not return scan results.").strip()
        raise ValueError(message[-1200:])
    return result.stdout

@app.errorhandler(RequestEntityTooLarge)
def too_large(_error):
    flash("Upload rejected: XML file must be 10 MB or smaller.", "error")
    return redirect(url_for("index"))

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        upload = request.files.get("scan_file")
        target = (request.form.get("target_ip") or "").strip()
        if not upload or not upload.filename:
            flash("Choose an Nmap XML file to upload.", "error")
            return redirect(url_for("index"))
        if os.path.splitext(secure_filename(upload.filename))[1].lower() != ALLOWED_EXTENSION:
            flash("Only .xml files are accepted.", "error")
            return redirect(url_for("index"))
        scanner_ip = request.remote_addr or "Unavailable"
        try:
            scan = parse_nmap_xml(upload.stream, scanner_ip, target or "Imported XML")
            save_scan(scan); save_incident(scan)
            flash("Nmap XML parsed successfully. Scan and incident history updated.", "success")
        except ValueError as exc:
            flash(str(exc), "error")
        return redirect(url_for("index"))
    return render_template("index.html", scan=read_latest_scan(), incidents=read_incidents())

@app.route("/scan", methods=["POST"])
def scan_network():
    raw_scope = request.form.get("network_scope", "")
    try:
        scope = validate_scope(raw_scope)
        xml_text = run_nmap_scan(scope)
        scan = parse_nmap_xml(io.BytesIO(xml_text.encode("utf-8")), request.remote_addr or "127.0.0.1", f"Automatic scan: {scope}")
        save_scan(scan); save_incident(scan)
        flash(f"Scan completed: {scan['total_hosts']} active host(s) found in {scope}.", "success")
    except ValueError as exc:
        flash(str(exc), "error")
    return redirect(url_for("index"))

@app.route("/module/<int:module_id>")
def module(module_id):
    if module_id not in (1, 2, 3, 4):
        return redirect(url_for("index"))
    return render_template(f"module{module_id}.html", scan=read_latest_scan(), incidents=read_incidents())

if __name__ == "__main__":
    ensure_local_files()
    print("Campus Network Intrusion Detection and Monitoring Platform")
    print("Open http://127.0.0.1:5000 in your browser.")
    app.run(host="127.0.0.1", port=5000, debug=False)
