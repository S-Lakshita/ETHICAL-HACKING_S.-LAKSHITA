CAMPUS NETWORK INTRUSION DETECTION AND MONITORING PLATFORM
==========================================================

ABOUT
-----
A local Flask dashboard that parses REAL Nmap XML files produced by your
authorized lab scan. It does not launch scans and does not include fake
scan records. All four module pages read the same latest_scan.json file.

REQUIREMENTS
------------
- Windows 10/11
- Python 3.9 or newer
- Nmap installed on your authorized Kali Linux lab machine
- A browser

FIRST-TIME SETUP (WINDOWS)
--------------------------
1. Extract the ZIP folder.
2. Open Command Prompt in the extracted project folder.
3. Install Flask:

       py -m pip install Flask

4. Start the dashboard:

       py app.py

5. Open this address in your browser:

       http://127.0.0.1:5000

WORKFLOW
--------
1. On your authorized Kali Linux lab, run the scan against the host you
   are permitted to assess. Example:

       nmap -sV -oX scan.xml 10.0.2.2

2. Transfer scan.xml to the Windows computer running this dashboard.
3. On the dashboard, enter the authorized target IP (for example 10.0.2.2).
4. Select scan.xml and click "Upload and Analyze".
5. Open Module 1, Module 2, Module 3 and Module 4 from the navigation bar.

PROJECT PAGES
-------------
/             Dashboard and XML upload
/module/1     Network reconnaissance and port/service inventory
/module/2     Network exposure and intrusion-analysis indicators
/module/3     Rule-based threat classification and recommendations
/module/4     Incident details and incident history

LOCAL DATA
----------
data/latest_scan.json
    The most recently uploaded and successfully parsed scan.

data/incident_history.csv
    One new incident-history row for each successful XML upload.

Both files are created locally and remain after the app is closed. Back them
up if you need to preserve project evidence. The app does not require a
database server or an internet connection after Flask is installed.

RISK CLASSIFICATION RULE
------------------------
0-9 open services  : LOW
10-19 open services: MEDIUM
20+ open services  : HIGH

The risk rule counts only ports whose Nmap XML state is "open". No additional
services are invented.

IMPORTANT INTERPRETATION NOTES
------------------------------
- The scanner IP shown by this local web app is the IP address of the client
  connecting to Flask (request.remote_addr). When you upload the XML using
  the browser on the same Windows computer, this will normally be 127.0.0.1.
  Standard Nmap XML does not reliably contain the scanner's source interface
  IP, so the app does not pretend this value is the Kali scanner's IP.
- "Suspicious activity" is presented as exposure-review indicators based on
  observed open services (for example SMB on port 445). An open port is not
  proof of compromise, an intrusion, or an exploitable vulnerability.
- Port 5000 is identified only as the service name reported by Nmap. Review
  the actual service/product/version in your XML and secure it appropriately.
- This dashboard is intended for authorized lab monitoring and educational
  demonstration. Scan only systems for which you have permission.

TROUBLESHOOTING
---------------
'py' is not recognized:
    Install Python from python.org and enable the option to add Python to PATH.

'No module named flask':
    Run: py -m pip install Flask

'Invalid Nmap XML':
    Confirm that the file was generated with -oX, and select the XML file,
    not the normal terminal text output.

'Entered target IP does not match':
    Enter the IP address that appears in the Nmap XML for the scanned host.

Port 5000 already in use:
    Close the other local app using port 5000, then run py app.py again.

To stop the server:
    Press Ctrl+C in the Command Prompt window.

FOLDER CONTENTS
---------------
app.py
templates/          All Flask/Jinja pages
static/style.css    Dashboard styling
data/               Local JSON and CSV history files
README.txt
requirements.txt


AUTOMATIC SCANNING UPGRADE
--------------------------
The dashboard now includes a Scan Network form. It runs Nmap on the same
Windows computer as Flask and parses the XML output automatically.
The manual XML upload remains available as a fallback.

Requirements:
1. Install Nmap for Windows from https://nmap.org/download.html
2. During installation, allow Nmap to be added to PATH if offered.
3. Close and reopen the terminal after installation.
4. Confirm with: nmap --version
5. Start the website: py app.py
6. Open: http://127.0.0.1:5000

In the Scan Network box, enter one authorised private IPv4 address
(e.g. 10.0.2.2) or a small authorised private network range
(e.g. 10.0.2.0/24). The app limits network ranges to 256 addresses.
Only scan systems and networks you own or have explicit permission to test.

Note: A /24 range can include up to 256 addresses. Nmap service detection
may take several minutes. This is an on-demand scan, not continuous
packet-level monitoring. Risk labels are simple exposure indicators,
not proof of compromise.
